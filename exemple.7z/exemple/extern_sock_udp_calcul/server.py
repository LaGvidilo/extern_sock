# -*- coding: utf-8 -*-
import extern_sock_udp as udp
from multiprocessing import Pool
import time

def f1(x):
	return int(x)*int(x)

def __main__():
	l=[]
	W,cumul=1,0
	while W==1:
		if cumul==0:
			R = udp.recv_wait_send(reponse="Done",print_s=0)
			print "COMMANDE:",R
			if R == "shutdown": W=0
			if R == "test": print "CECI EST UN TEST, EFFECTUER AVEC SUCCES."
			if R == "cumul": cumul,r=1,[]			
			if R == "pow":
				p=Pool(5)
				r=p.map(f1, l)
				cumul=-1
			
		if cumul==1:
			R = udp.recv_wait_send(reponse="Done",print_s=0)
			if R == "end": cumul=0			
			else: 
				if R!="cumul": l.append(R)
				time.sleep(0.1)
			print R,l
		if cumul==-1:
			time.sleep(2)
			n,e=0,len(r)
			while n<e:
				R = udp.send_wait_recv(reponse=str(r[n]),print_s=0)
				print "envoi:",str(r[n])
				n=n+1
				time.sleep(0.5)
				
			udp.send_wait_recv(reponse="end",print_s=0)
			cumul=0
			
			

if __name__ == '__main__':
	__main__()
