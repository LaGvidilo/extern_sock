# -*- coding: utf-8 -*-
import extern_sock_udp as udp
import time



def __main__():
	l=[5,4,6,8,1,0,1,2,4,5,6,8,9,9,1,0,5,3,4,7,9,6,5,9,5,4,9,5,6,3,2,1,0,1,8,9,1,1]
	serv_address=raw_input("Server IP> ")
	W,cumul=1,0
	while W==1:
		msg=raw_input("reponse> ")
		if msg=="exit":
			W=0
		if msg=="cumul": cumul = 1
		if msg=="pow": cumul = -1
			
		if cumul==0:
			R = udp.send_wait_recv(serv_address=serv_address,reponse=msg,send_port=21566,recv_port=21568,print_s=0)
			if R[:4]=='Done':
				print "Accusé de recption.\nLe serveur à reçu correctement les données."
		
		if cumul==1:	
			R = udp.send_wait_recv(serv_address=serv_address,reponse=msg,send_port=21566,recv_port=21568,print_s=0)	
			n,e=0,len(l)
			while n<e:
				R = udp.send_wait_recv(serv_address=serv_address,reponse=str(l[n]),send_port=21566,recv_port=21568,print_s=0)
				n=n+1
				time.sleep(0.3)
			R = udp.send_wait_recv(serv_address=serv_address,reponse="end",send_port=21566,recv_port=21568,print_s=0)
			cumul=0


		if cumul==-1:
			R = udp.send_wait_recv(serv_address=serv_address,reponse=msg,send_port=21566,recv_port=21568,print_s=0)
			R = ""
			l2=[]
			while R!="end":
				R = udp.recv_wait_send(serv_address=serv_address,reponse="Done",send_port=21566,recv_port=21568,print_s=0)
				if R!="end": l2.append(R)
				print "reception:", R
			print l2
			
				

if __name__ == '__main__':
	__main__()
