import socket

# ENVOI
def send_reponse(reponse="None",serv_address='127.0.0.1',send_port=21568,print_s=1):
	UDPSock=socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	data = reponse+"\n"
	addr = (serv_address, send_port)
	UDPSock.sendto(data,addr)
	if print_s==1:
		print (str(len(data.strip()))+"oct"," - To:",addr)

# RECEPTION
def recv_reponse(size_recv=1024,recv_port=21566,print_s=1):
	UDPSock=socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	listen_addr = ("",recv_port)
	UDPSock.bind(listen_addr)
	data,addr = UDPSock.recvfrom(size_recv)
	if print_s==1:
		print (data.strip()," - From:",addr)
	return data.strip()

# ENVOI DOUBLE, ATTENTE ACCUSE DE RECEPTION
def send_wait_recv_two(reponse_cmd="None",reponse="None",serv_address='127.0.0.1',send_port=21568,size_recv=1024,recv_port=21566,print_s=1):
	send_reponse(reponse_cmd,serv_address,send_port,print_s)	
	send_reponse(reponse,serv_address,send_port,print_s)
	R=recv_reponse(size_recv,recv_port,print_s)
	return R

# ENVOI, ATTENTE ACCUSE DE RECEPTION
def send_wait_recv(reponse="None",serv_address='127.0.0.1',send_port=21568,size_recv=1024,recv_port=21566,print_s=1):	
	send_reponse(reponse,serv_address,send_port,print_s)
	R=recv_reponse(size_recv,recv_port,print_s)
	return R

# RECEPTION + ENVOI ACCUSE DE RECEPTION
def recv_wait_send(reponse="None",serv_address='127.0.0.1',send_port=21568,size_recv=1024,recv_port=21566,print_s=1):	
	R=recv_reponse(size_recv,recv_port,print_s)
	send_reponse(reponse,serv_address,send_port,print_s)
	return R
	
